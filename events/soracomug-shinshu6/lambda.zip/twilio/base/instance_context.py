class InstanceContext(object):
    def __init__(self, version):
        """
        :param Version version:
        """
        self._version = version
        """ :type: Version """

