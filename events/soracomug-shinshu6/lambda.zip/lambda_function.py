from twilio.rest import Client

def lambda_handler(event, context):
    # 入力値処理
    twilio_sid = event['placementInfo']['attributes']['twilio_sid']
    twilio_token = event['placementInfo']['attributes']['twilio_token']
    twilio_flowid = event['placementInfo']['attributes']['twilio_flowid']
    twilio_number = event['placementInfo']['attributes']['twilio_number']
    twilio_callto = event['placementInfo']['attributes']['twilio_callto']

    client = Client(twilio_sid, twilio_token)
    execution = client.studio.flows(twilio_flowid).executions.create(
        to=twilio_callto,
        from_=twilio_number
    )

    return execution.sid

